# README

## packages need to be installed
sklearn==1.1.2
xgboost==2.0.0
imblearn==0.11.0
seaborn==0.13.0